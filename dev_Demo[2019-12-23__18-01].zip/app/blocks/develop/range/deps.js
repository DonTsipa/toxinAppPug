
module.exports = {

    modules: [
    {
        from: 'node_modules/nouislider/distribute',
        inject: [ 'nouislider.js','nouislider.css' ],
    },

    ]  

  }