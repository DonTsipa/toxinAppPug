
/*module.exports = {
    modules: [
       {
        from: 'app/fonts',
        inject: [ 'fontawesome.min.css' ],
       },
    ]  
  }*/