let add = (a,b)=>{
    console.log(a+b);
};
add('fuck','off');